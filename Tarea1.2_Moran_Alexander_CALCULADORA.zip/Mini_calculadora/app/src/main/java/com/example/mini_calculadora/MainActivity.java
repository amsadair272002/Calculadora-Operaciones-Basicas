package com.example.mini_calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    EditText et1, et2 ;
    TextView tv1;
    Button btnSumar, btnRestar, btnmultiplicar, btnDividir  ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1 = (EditText)findViewById(R.id.txtNumero1);
        et2 = (EditText)findViewById(R.id.txtNumero22);
        tv1 = (TextView)findViewById(R.id.lblResultado);

        btnSumar = (Button) findViewById(R.id.btnSumar);
        btnSumar.setOnClickListener(this);

        btnRestar = (Button) findViewById(R.id.btnRestar);
        btnRestar.setOnClickListener(this);

        btnmultiplicar = (Button) findViewById(R.id.btnMultiplicar);
        btnmultiplicar.setOnClickListener(this);

        btnDividir = (Button) findViewById(R.id.btnDividir);
        btnDividir.setOnClickListener(this);


    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onClick(View v) {
        float n1,n2,ress,resr, resm = 0, resd = 0;
        n1 = Float.parseFloat(et1.getText().toString());
        n2 = Float.parseFloat(et2.getText().toString());
        ress = n1 + n2;
        resr = n1 - n2;
        resm = n1 * n2;
        resd = n1/n2;

        tv1.setText("El resultado es: "+ress);
        Toast.makeText(getApplicationContext(),"El resultado es: "+ress, Toast.LENGTH_LONG).show();

        tv1.setText("El resultado es: "+resr);
        Toast.makeText(getApplicationContext(),"El resultado es: "+resr, Toast.LENGTH_LONG).show();

        tv1.setText("El resultado es: "+resm);
        Toast.makeText(getApplicationContext(),"El resultado es: "+resm, Toast.LENGTH_LONG).show();

        tv1.setText("El resultado es: "+resd);
        Toast.makeText(getApplicationContext(),"El resultado es: "+resd, Toast.LENGTH_LONG).show();





    }
}